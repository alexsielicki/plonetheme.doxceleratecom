$(function(){
	$("#faded").faded({
		speed: 500,
		crossfade: true,
		autoplay: 5000,
		autopagination:false
	});
});